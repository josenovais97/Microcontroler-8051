#ifndef _TYPES_HEADER_
#define _TYPES_HEADER_

typedef unsigned char uint8_t;

#endif