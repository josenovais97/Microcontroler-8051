#include <REG51F380.H>
#include "init_device.h"

sbit pb1 = P0^6;
sbit pb2 = P0^7;
sbit seg_dp = P2^7;
sbit porto17=P1^7;
sbit oc=P1^4;
sbit bip=P1^6;
static int blink = 100;
code const char seg_num[] = {0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78, 0x00, 0x10};
code const char seg_states[] = {0x47, 0x23, 0x06, 0x08, 0xC6};
char codigo[4]={8,0,5,1};
char user_code[4]={0,0,0,0};
int index=0;
int indexc=0;
int code_index=0;
int code_change=0;
int result = 2;
int tentativas=0;
int i,j=0;
int flag=0;

typedef enum ENUM_STATES {S1 = 0, S2, S3, S4, S5} e_states;

e_states state, nextstate;

/*prototipos funoes*/
void Locked(void);
void Open(void);
void Error(void);
void Alarm(void);
void Change(void);
void led_blink(void);	
void timer2_init_auto(int reload);
	
void Locked(void){
		P2 = seg_states[state];
	oc=1;
		while(pb1 == 1);
		while(code_index<4){
			P2=seg_num[index];
			if(pb1==0){
					index++;
					if(index>9){
						index=0;
					}
				P2=seg_num[index];
					while(pb1==0);
				}
				if(pb2==0){
					user_code[code_index]=index;
					code_index++;
					index=0;
					while(pb2==0);
				}
		}
		code_index=0;
		for(i=0;i<4;i++){
			if(user_code[i]==codigo[i]){
				j++;
			}
		}
		if(j<4){
		nextstate=S3;
		}
		else{
		nextstate=S2;
		}
		j=0;
}
void Open(void){
		P2 = seg_states[state];
	oc=0;
	while(1){
		if(pb1==0){
			nextstate=S5;
			while(pb1==0);
			return;
		}
		if(pb2==0){
			nextstate=S1;
			while(pb2==0);
			return;
		}
	}
}
void Error(void){
		P2 = seg_states[state];
	tentativas++;
	flag=0;
	timer2_init_auto(10000000*tentativas);
	TF2H = 0;	
	ET2 = 1;
	TR2 = 1;
	while(1){	
		while(!TF2H);
		TF2H = 0;	
		if(--blink == 0){
			blink = 100;
		flag++;
		if(flag==6){
		break;
		}
		}
	}
	nextstate=S1;
	if(tentativas==5){
		nextstate=S4;
		tentativas=0;
	}
}
void Alarm(void){
		P2 = seg_states[state];
	bip=1;
	timer2_init_auto(62536);
	while(1){
		while(!TF2H);
		TF2H = 0;	
		bip = !bip;
	}
}
void Change(void){
		P2 = seg_states[state];
	led_blink();
	while(pb1==1);
	while(code_change<4){
		P2=seg_num[indexc];
			if(pb1==0){
					indexc++;
					if(indexc>9){
						indexc=0;
					}
					P2=seg_num[indexc];
					while(pb1==0);
				}
				if(pb2==0){
					codigo[code_change]=indexc;
					code_change++;
					indexc=0;
					while(pb2==0);
				}
	}
	code_change=0;
	nextstate=S1;
}

void encode_FSM_switch(){
		switch (state) {
			case S1:
							Locked();
							break;
			case S2:
							Open();
							break;
			case S3:
							Error();
							break;
			case S4:
							Alarm();
							break;
			case S5:
							Change();
							break;
			default: break;
		}
}

void timer2_init_auto(int reload){

	TMR2CN = 0;

#define B_T2MH 5	

	CKCON &= ~((1 << B_T2MH));
	
	TMR2H = (reload) >> 8;
	TMR2L = (reload & 0xFF);

	TMR2RLH = (reload) >> 8;
	TMR2RLL = (reload & 0xFF);
}

void led_blink(void) {
  int flag=0;
	timer2_init_auto(34952);
	TF2H = 0;	
	ET2 = 1;
	TR2 = 1;
	while(1){
			
		while(!TF2H);
		TF2H = 0;	

		if(--blink == 0){
			seg_dp ^= 1;
			blink = 100;
		flag++;
		if(flag==6){
		break;
		}
		}
	}
}

/*******************
 *    main function																	 		 *
 *******************/
void main (void){
	
	Init_Device();
	
	TF2H = 0;	
	ET2 = 1;
	TR2 = 1;
		
	if(porto17==1){
		state = nextstate = S1;
	}
	else{
		Change();
	}
	P2 = seg_states[state];
	
	while (1) {
			
		encode_FSM_switch();
		state = nextstate;
	}
}