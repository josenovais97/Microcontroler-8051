#include <REG51F380.h>

sbit pb1 = P0^6;
sbit pb2 = P0^7;

code const char seg_data[] = {0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78, 0x00, 0x10, 0x08, 0x03, 0x46, 0x21, 0x06, 0x0E};
char index = 0; // Controlar o indice do array.

void init_device(void) {
    FLSCL = 0x10;
    CLKSEL = 0x03;
    PCA0MD = 0x00;
    XBR1 = 0x40;
    P2=0x40; //Inicia o display a 0, sem esta linha de c�digo o display inciava apagado.
}

void main() {
    bit pb1_atual, pb2_atual;
    bit pb1_anterior = 1, pb2_anterior = 1; // Estado anterior.

    init_device();
	
    while(1){
       pb1_atual = pb1;
       pb2_atual = pb2;

        // Debounce
        if (pb1_atual == 0 && pb1_anterior == 1) {
            index++; //Se isto se verificar o bot�o PB1 foi carregado e avan�a para a pr�xima posi��o.
            if (index > 0x0F) {
                index = 0x0F; // Para quando chegar ao "F".
            }
            P2 = seg_data[index];
        }
        
        if (pb2_atual == 0 && pb2_anterior == 1) {
            index--;// Quando verificamos esta condi��o PB2 foi carregado e recua para a posi��o anterior.
            if (index < 0x00) {
                index = 0x00; // Para quando chegar ao "0".
            }
            P2 = seg_data[index];	
        }

        pb1_anterior = pb1_atual;
        pb2_anterior = pb2_atual;
    }
	}